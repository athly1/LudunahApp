
import SwiftUI

@main
struct LudoonaApp: App {

    @State private var appState = AppState()
    @State private var appRouter = AppRouter()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(appState)
                .environment(appRouter)
                .environment(\.layoutDirection, .rightToLeft)
                .background(Color.pageBackground.ignoresSafeArea())
        }
    }
}

private struct RootView: View {

    @Environment(AppState.self) private var appState
    @Environment(AppRouter.self) private var appRouter

    @State private var showSplash = true

    var body: some View {
        @Bindable var router = appRouter

        Group {
            if showSplash {
                SplashView()
                    .task {
                        print("RootView: timer started")

                        do {
                            try await Task.sleep(for: .seconds(2))
                        } catch {
                            return
                        }

                        guard !Task.isCancelled else {
                            return
                        }

                        print("RootView: timer finished")

                        withAnimation(.easeInOut(duration: 0.3)) {
                            showSplash = false
                        }
                    }

            } else if appState.isOnboardingCompleted {
                NavigationStack(path: $router.path) {
                    HomeView()
                        .navigationDestination(for: AppRoute.self) { route in
                            router.destination(for: route)
                        }
                }
                .onAppear {
                    print("RootView: HomeView appeared")
                }

            } else {
                OnboardingView()
                    .onAppear {
                        print("RootView: New OnboardingView appeared")
                    }
            }
        }
        .onChange(of: appState.isOnboardingCompleted) { oldValue, newValue in
            print("Onboarding state changed: \(oldValue) -> \(newValue)")
        }
    }
}
        
